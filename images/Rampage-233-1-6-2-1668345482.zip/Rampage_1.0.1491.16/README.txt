>--- Overview ----<
Rampage is a Trainer / Modification for Red Dead Redemption 2 Story Mode

Please keep in mind that this product is a WIP project that is evolving through time. It is not a finished release product where everything is working perfectly.
This is a mod that depends on research and R* Patches,
That means in general that functions have to be researched and there are certain borders and limits in what is possible and also what R* allows us to do.


>--- How to Install ---<
Extract the .zip file and put the Rampage.asi and RampageFiles into your RDR2 Directory.
Make sure you have the latest version of Alexander Blades ScriptHookRDR2 plugin (ScriptHookRDR2.dll & dinput8.dll)
If you have any issues with dinpu8.dll you can also just use version.dll from LMS to load your .asi files.
It's also requiered to use version.dll if you want content from RDO to be usable in Singleplayer

If RDR2 is installed on your main drive (C:) or you get any issues regarding not being able to save file make sure 
that your user account and the user group have the correct permissions for the game folder.


>--- Troubleshooting ---<
If you encounter any issues while loading such as "Settings.json missing" or "Hotkey.json missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart RDR2.


>--- Common Questions ---<
Q: How can i disable the Prompt that shows Open F5?
A: Go into Settings->Extended UI->Disable "Open Info"

Q: How can i get out of creator mode?
A: Creator mode toggles when you press Ctrl + C on Keyboard you can disable this in Settings->Hotkey Manager-> Disable "Creator Hotkey"

Q: I can't move and I have a cursor on my screen!
A: You may toggled cursor mode, that happens when you press X you can either change the Key in Settings->Hotkey Manager-> "Cursor Key" or disable it completly.



>--- Known issues ---<
Options that access RDR`s entity pools like Local Peds & Local Vehicle options, Black hole etc. tend to crash if there are to many entites.
To prevent crashing because of too many spawned objects try to delete old ones first and free the memory by deleting world vehicles / peds.


>--- Important Things ---<
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the Option and enter your new hotkey inside the window.

Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

If you make any changes like changing the colors or other settings in order to save them you need to manually save them
under Settings -> Load / Save.


>--- Issues and Bug Reporting ---<
If you encounter any issues or bugs or your game crashes you can submit a bug report.
For a bug report please provide some general information like What options you used, what other mods you used
did you load any savegame?, did you played any missions or just free play? You can always find a Log inside the Rampagefiles folder in the subfolder Logs.
If you encounter any crashes you can enable Advanced Logging on version 1.3.5 and higher (Settings->Debug) you can then submit your log file to make it easier to track down issues.


>--- Controls ---<
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F5
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Number, Decimal, List) = Right/Left Arrow key or Numpad4 and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5


>--- Terms & Rules ---<
The Software is provided "As Is", without warranty of any kind.
The Software is completely free and it's forbidden to sell or use it in any commercial way.
You are not allowed to redistribute this software without permission.
You are not allowed to modify or reverse code aswell as debugging / patching
You take full responsibility for your actions using this product.
Software support may be stopped at any time without any reason.
This terms may be updated at any time without any reason.

>--- Credits ---<

RDR2 Modding Resources
-> alloc8or Native DB
-> Alexander Blade For ScriptHookRDR2
-> rdr2mods
-> RedM


>--- Changelog ---<

Version 1.6.2

-> Added extra submenu for ped weapons
-> Added Light Propsets for vehicles
-> Added Option that allows the chauffeur to drive to a next location without respawning the coach
-> Added search for timecycle modifiers
-> Added search for game music events
-> Added Mag1 Demo toggle
-> The mobile stable got a complete overhaul
-> Setting the players weight is now permanent and affects status effects
-> Improved Max Horse Bonding
-> Improved Entity Rotation in creator mode
-> Improved update checking function
-> Improved "Add Item to Inventory" function
-> Fixed Mobile Theater window alignment
-> Fixed an issue that caused cursor mode activation when changing ammo type in weapon wheel
-> Fixed an issue with deleting dead peds from ped database could cause inconsistent data
-> Fixed issues with overlapping hud elements due to gfx draw oder changes
-> Ped, Vehicle and Object ESP can now be toggled globally
-> Currency values are now formatted properly with $ and ct